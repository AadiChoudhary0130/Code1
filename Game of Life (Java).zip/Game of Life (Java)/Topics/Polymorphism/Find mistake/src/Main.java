public class Main {

    public static void main(String[] args) {
        new TeamLead(1);
    }

    public static class TeamLead extends Programmer {

        private final int numTeamLead;

        public TeamLead(int numTeamLead) {
            this.numTeamLead = numTeamLead;
            employ();
        }

        // You can override employ() here if needed.

    }

    public static class Programmer {

        private final int numProgrammer;

        public Programmer() {
            this.numProgrammer = 1; // Assuming default value for the number of programmers is 1
            employ();
        }

        protected void employ() {
            System.out.println(numProgrammer + " programmer");
        }
    }
}
