package life;

import java.util.Random;
import java.io.Serializable;

public class GameOfLife implements Serializable{
    public static final char ALIVE_CELL = 'O';
    public static final char DEAD_CELL = ' ';

    public char[][] currentGeneration;
    public char[][] nextGeneration;
    public int size;
    public int aliveCells;
    public Random random;

    public GameOfLife(int size, long seed) {
        this.size = size;
        currentGeneration = new char[size][size];
        nextGeneration = new char[size][size];
        random = new Random(seed);
        aliveCells = 0; // Initialize aliveCells

        initializeRandomGeneration();
    }

    public void initializeRandomGeneration() {
        aliveCells = 0; // Reset aliveCells before each simulation
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                currentGeneration[i][j] = (random.nextBoolean()) ? ALIVE_CELL : DEAD_CELL;
                if (currentGeneration[i][j] == ALIVE_CELL) {
                    aliveCells++;
                }
            }
        }
    }

    public void simulateGenerations(int numGenerations) {
        for (int generation = 0; generation <= numGenerations; generation++) {
            System.out.println("Generation: " + generation);
            System.out.println("Alive: " + aliveCells);
            printCurrentGeneration();
            simulateGeneration2(numGenerations);

            // Sleep for a specified duration (e.g., 50 milliseconds)
            sleep(50);
        }
    }

    public char[][] getCurrentGeneration() {
        return currentGeneration;
    }

    public int getSize() {
        return size;
    }

    public int getAliveCells() {
        return aliveCells;
    }

    public void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void printCurrentGeneration() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(currentGeneration[i][j]);
            }
            System.out.println();
        }
    }

    public void simulateGeneration2(int generation) {
        aliveCells = 0; // Reset aliveCells before each simulation
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                int liveNeighbors = countLiveNeighbors(i, j);

                if (currentGeneration[i][j] == ALIVE_CELL) {
                    if (liveNeighbors == 2 || liveNeighbors == 3) {
                        nextGeneration[i][j] = ALIVE_CELL; // Cell survives
                        aliveCells++;
                    } else {
                        nextGeneration[i][j] = DEAD_CELL; // Cell dies
                    }
                } else {
                    if (liveNeighbors == 3) {
                        nextGeneration[i][j] = ALIVE_CELL; // Cell is reborn
                        aliveCells++;
                    } else {
                        nextGeneration[i][j] = DEAD_CELL; // Cell remains dead
                    }
                }
            }
        }

        // Swap current and next generations
        char[][] temp = currentGeneration;
        currentGeneration = nextGeneration;
        nextGeneration = temp;
    }

    public int countLiveNeighbors(int x, int y) {
        int liveNeighbors = 0;
        int[] dx = {-1, -1, -1, 0, 0, 1, 1, 1};
        int[] dy = {-1, 0, 1, -1, 1, -1, 0, 1};

        for (int i = 0; i < 8; i++) {
            int nx = (x + dx[i] + size) % size; // Using the size modulo should work.
            int ny = (y + dy[i] + size) % size;

            if (currentGeneration[nx][ny] == ALIVE_CELL) {
                liveNeighbors++;
            }
        }

        return liveNeighbors;
    }
}
