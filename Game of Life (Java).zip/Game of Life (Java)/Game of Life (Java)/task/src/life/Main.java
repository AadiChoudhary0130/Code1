package life;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GUIGameOfLife gui = new GUIGameOfLife(25, System.currentTimeMillis());
            gui.setVisible(true);
        });
    }
}
