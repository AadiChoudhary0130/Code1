
class Time {
    int hours;
    int minutes;
    int seconds;

    // Constructor 1: Takes only hours and initializes the hours field
    public Time(int hours) {
        this.hours = hours;
        this.minutes = 0;
        this.seconds = 0;
    }

    // Constructor 2: Takes hours and minutes and initializes the corresponding fields
    public Time(int hours, int minutes) {
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = 0;
    }

    // Constructor 3: Takes hours, minutes, and seconds and initializes all fields
    public Time(int hours, int minutes, int seconds) {
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = seconds;
    }
}




