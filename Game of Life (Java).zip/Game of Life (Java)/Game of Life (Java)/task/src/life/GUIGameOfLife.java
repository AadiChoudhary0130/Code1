package life;

// Importing the necessary libraries for the code to work.
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.image.BufferedImage;

public class GUIGameOfLife extends JFrame {
    private static final int FIXED_GRID_SIZE = 750;
    private GameOfLife game;
    private Timer timer;
    private int generation;
    private JToggleButton pauseResumeButton;
    private JButton restartButton;
    private static final int textSize = 30;
    private BufferedImage offScreenImage;
    private JSlider speedSlider;
    private JTextField sizeTextField;

    private Color aliveCellColor = Color.GREEN;
    private Color deadCellColor = Color.RED;

    private GraphicsPanel graphicsPanel; // New GraphicsPanel instance

    public GUIGameOfLife(int size, long seed) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        int cellSize = FIXED_GRID_SIZE / size;
        setSize(FIXED_GRID_SIZE, FIXED_GRID_SIZE + 100);

        setUndecorated(true);

        game = new GameOfLife(25, seed);
        generation = 0;

        timer = new Timer(2000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (game.getSize() > 0) {
                    game.simulateGenerations(1);
                    generation++;
                    repaint();
                }
            }
        });

        pauseResumeButton = new JToggleButton("Pause");
        pauseResumeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (pauseResumeButton.isSelected()) {
                    timer.stop();
                    pauseResumeButton.setText("Resume");
                } else {
                    timer.start();
                    pauseResumeButton.setText("Pause");
                }
            }
        });

        restartButton = new JButton("Restart");
        restartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.initializeRandomGeneration();
                generation = 0;
                repaint();
            }
        });

        speedSlider = new JSlider(JSlider.HORIZONTAL, 100, 2000, 1000);
        speedSlider.setMajorTickSpacing(500);
        speedSlider.setMinorTickSpacing(100);
        speedSlider.setPaintTicks(true);
        speedSlider.setSnapToTicks(true);
        speedSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                timer.setDelay(speedSlider.getValue());
            }
        });

        graphicsPanel = new GraphicsPanel(generation, aliveCellColor, deadCellColor); // Initialize GraphicsPanel

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(null);

        pauseResumeButton.setBounds(650, 15, 80, 25);
        restartButton.setBounds(575, 15, 70, 25);
        speedSlider.setBounds(405, 15, 165, 25);

        JButton setSizeButton = new JButton("Set Size");
        setSizeButton.setBounds(15, 810, 80, 25);
        setSizeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int newSize = Integer.parseInt(sizeTextField.getText());

                    if (newSize <= 0) {
                        JOptionPane.showMessageDialog(GUIGameOfLife.this, "Grid size cannot be 0 or negative. Setting grid size to 25.");
                        newSize = 25;
                    } else if (newSize > 375) {
                        JOptionPane.showMessageDialog(GUIGameOfLife.this, "Too big, the maximum size is 375. Setting grid size to 25.");
                        newSize = 25;
                    }

                    game = new GameOfLife(newSize, seed);
                    generation = 0;
                    repaint();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(GUIGameOfLife.this, "Invalid input. Please enter a valid number. Setting grid size to 25.");
                }
            }
        });

        sizeTextField = new JTextField();
        sizeTextField.setBounds(105, 810, 80, 25);
        buttonPanel.add(sizeTextField);

        JButton aliveCellColorButton = new JButton("Alive Cell Color");
        aliveCellColorButton.setBounds(195, 810, 140, 25);
        aliveCellColorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                aliveCellColor = JColorChooser.showDialog(GUIGameOfLife.this, "Choose Alive Cell Color", aliveCellColor);
                repaint();
            }
        });

        JButton deadCellColorButton = new JButton("Dead Cell Color");
        deadCellColorButton.setBounds(345, 810, 140, 25);
        deadCellColorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deadCellColor = JColorChooser.showDialog(GUIGameOfLife.this, "Choose Dead Cell Color", deadCellColor);
                repaint();
            }
        });

        JButton saveButton = new JButton("Save Game");
        saveButton.setBounds(495, 810, 110, 25);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveGame();
            }
        });

        JButton loadButton = new JButton("Load Game");
        loadButton.setBounds(615, 810, 120, 25);
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadGame();
            }
        });

        buttonPanel.add(pauseResumeButton);
        buttonPanel.add(restartButton);
        buttonPanel.add(speedSlider);
        buttonPanel.add(setSizeButton);
        buttonPanel.add(aliveCellColorButton);
        buttonPanel.add(deadCellColorButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(loadButton);

        // Add the GraphicsPanel to the main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.add(graphicsPanel);
        mainPanel.add(buttonPanel);
        add(mainPanel);

        timer.start();
    }

    private void saveGame() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Game State");
        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            ObjectOutputStream oos = null;
            try {
                oos = new ObjectOutputStream(new FileOutputStream(fileToSave));
                oos.writeObject(game);
                oos.writeObject(aliveCellColor);
                oos.writeObject(deadCellColor);
                oos.writeInt(generation);
                JOptionPane.showMessageDialog(this, "Game state saved successfully!");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving game state.", "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                if (oos != null) {
                    try {
                        oos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void loadGame() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Load Game State");

        int userSelection = fileChooser.showOpenDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToLoad = fileChooser.getSelectedFile();
            ObjectInputStream ois = null;
            try {
                ois = new ObjectInputStream(new FileInputStream(fileToLoad));
                game = (GameOfLife) ois.readObject();
                aliveCellColor = (Color) ois.readObject();
                deadCellColor = (Color) ois.readObject();
                generation = ois.readInt();
                repaint();
                JOptionPane.showMessageDialog(this, "Game state loaded successfully!");
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error loading game state.", "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                if (ois != null) {
                    try {
                        ois.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        if (offScreenImage == null || offScreenImage.getWidth() != getWidth() || offScreenImage.getHeight() != getHeight()) {
            offScreenImage = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
        }

        Graphics offScreenGraphics = offScreenImage.getGraphics();

        char[][] currentGeneration = getCurrentGeneration();

        int gameSize = getGameSize();

        if (gameSize > 0) {
            int cellSize = FIXED_GRID_SIZE / gameSize;
            int offsetX = (getWidth() - gameSize * cellSize) / 2;
            int offsetY = (getHeight() - gameSize * cellSize) / 2;

            offScreenGraphics.setColor(Color.BLACK);
            offScreenGraphics.fillRect(0, 0, getWidth(), getHeight());

            offScreenGraphics.setColor(Color.GRAY);
            offScreenGraphics.fillRect(0, 0, getWidth() / 2, 50);
            offScreenGraphics.fillRect(getWidth() / 2, 0, getWidth() / 2, 50);
            offScreenGraphics.fillRect(0, getHeight() - 50, getWidth(), 50);
            offScreenGraphics.setColor(Color.BLACK);

            offScreenGraphics.drawRect(0, 0, getWidth() / 2, 50);
            offScreenGraphics.drawRect(getWidth() / 2, 0, getWidth() / 2, 50);
            offScreenGraphics.drawRect(0, getHeight() - 50, getWidth(), 50);

            offScreenGraphics.setColor(Color.WHITE);
            offScreenGraphics.setFont(new Font("Arial", Font.PLAIN, Math.min(gameSize * cellSize / 4, 20)));

            String generationText = "Generation: " + generation + " | Alive Cells: " + game.getAliveCells();
            int textX = (getWidth() / 2 - offScreenGraphics.getFontMetrics().stringWidth(generationText)) / 2;
            offScreenGraphics.drawString(generationText, textX, 50 - textSize / 2);

            for (int i = 0; i < gameSize; i++) {
                for (int j = 0; j < gameSize; j++) {
                    Color cellColor = (currentGeneration[i][j] == GameOfLife.ALIVE_CELL) ? aliveCellColor : deadCellColor;
                    offScreenGraphics.setColor(cellColor);
                    offScreenGraphics.fillRect(j * cellSize + offsetX, i * cellSize + offsetY, cellSize, cellSize);
                    offScreenGraphics.setColor(Color.BLACK);
                    offScreenGraphics.drawRect(j * cellSize + offsetX, i * cellSize + offsetY, cellSize, cellSize);
                }
            }
        }

        offScreenGraphics.dispose();
        g.drawImage(offScreenImage, 0, 0, this);
    }

    public char[][] getCurrentGeneration() {
        return game.getCurrentGeneration();
    }

    public int getGameSize() {
        return game.getSize();
    }

    // Inner class for GraphicsPanel
    private class GraphicsPanel extends JPanel {
        private int generation;
        private Color aliveCellColor;
        private Color deadCellColor;

        public GraphicsPanel(int generation, Color aliveCellColor, Color deadCellColor) {
            this.generation = generation;
            this.aliveCellColor = aliveCellColor;
            this.deadCellColor = deadCellColor;
        }

        public void setGeneration(int generation) {
            this.generation = generation;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            int width = getWidth();
            int height = getHeight();

            g.setColor(Color.GRAY);
            g.fillRect(0, 0, width, 50);
            g.setColor(Color.BLACK);
            g.drawRect(0, 0, width, 50);

            g.setColor(Color.GRAY);
            g.fillRect(0, height - 50, width, 50);
            g.setColor(Color.BLACK);
            g.drawRect(0, height - 50, width, 50);

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, Math.min(width / 4, 20)));

            String generationText = "Generation: " + generation;
            int textX = (width - g.getFontMetrics().stringWidth(generationText)) / 2;
            g.drawString(generationText, textX, 25);

            g.dispose();
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(getWidth(), 100);
        }
    }
}
